﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace IPT_Lab2_233985
{
    class Program
    {
        static void Main(string[] args)
        {
            /**
             * arg0 - plik ze wzorcami
             * arg1 - plik wejściowy
             * arg2 - plik wyjściowy (wyniki)
             * arg3 - liczba iteracji
             */

            int itercount;

            if (args.Length != 4)
                Console.WriteLine("Invalid args count.");
            else if (!File.Exists(args[0]) || !File.Exists(args[1]))
                Console.WriteLine("One of input files path is invalid.");
            else if (!Int32.TryParse(args[3], out itercount))
                Console.WriteLine("Invalid index.");
            else
            {
                Stopwatch stopwatch = new Stopwatch();
                string text = File.ReadAllText(args[1]);
                FileStream fs = File.OpenWrite(args[2]);
                StreamWriter sw = new StreamWriter(fs);
                long total = 0;
                foreach (string pattern in File.ReadAllLines(args[0]))
                {
                    Console.WriteLine("Naive " + pattern.Length);
                    for (int i = 0; i < itercount; i++)
                    {
                        stopwatch.Start();
                        NaiveMatch(text, pattern);
                        stopwatch.Stop();
                        total += stopwatch.ElapsedMilliseconds;
                        stopwatch.Reset();
                    }
                    sw.WriteLine("naive," + pattern.Length + "," + (total / itercount));
                    sw.Flush();
                    total = 0;
                    Console.WriteLine("KMP " + pattern.Length);
                    for (int i = 0; i < itercount; i++)
                    {
                        stopwatch.Start();
                        KMPMatch(text, pattern);
                        stopwatch.Stop();
                        total += stopwatch.ElapsedMilliseconds;
                        stopwatch.Reset();
                    }
                    sw.WriteLine("kmp," + pattern.Length + "," + (total / itercount));
                    sw.Flush();
                    total = 0;
                    Console.WriteLine("Rabin-Karp " + pattern.Length);
                    for (int i = 0; i < itercount; i++)
                    {
                        stopwatch.Start();
                        RabinKarpMatch(text, pattern);
                        stopwatch.Stop();
                        total += stopwatch.ElapsedMilliseconds;
                        stopwatch.Reset();
                    }
                    sw.WriteLine("rabinkarp," + pattern.Length + "," + (total / itercount));
                    sw.Flush();
                    Console.WriteLine("Done with " + pattern.Length + " chars long pattern");
                }
                sw.Close();
            }
            Console.WriteLine("Done. Press any key to continue...");
            Console.ReadLine();
        }

        #region algs
        static void KMPMatch(string text, string pattern, bool logging = false)
        {
            int[] T = GenerateKMPTable(pattern);
            int i = 0;
            int j = 0;

            while (i < text.Length)
            {
                if (pattern[j] == text[i])
                {
                    i++;
                    j++;
                }
                if (j == pattern.Length)
                {
                    if (logging)
                        Console.WriteLine("Pattern found in " + i);
                    j = T[j - 1];
                }
                else if (i < text.Length && pattern[j] != text[i])
                {
                    if (j > 0)
                        j = T[j - 1];
                    else
                        i++;
                }
            }
        }

        static void NaiveMatch(string text, string pattern, bool logging = false)
        {
            int n = text.Length;
            int m = pattern.Length;
            for (int s = 0; s <= n - m; s++)
            {
                if (pattern.Equals(text.Substring(s, m)) && logging)
                    Console.WriteLine("Pattern found in " + (s + m));
            }
        }

        static void RabinKarpMatch(string text, string pattern, bool logging = false)
        {
            int n = text.Length;
            int m = pattern.Length;
            ulong hpattern = ComputeHash(pattern);

            for (int i = 0; i < n - m + 1; i++)
            {
                ulong hs = ComputeHash(text.Substring(i, m));
                if (hs == hpattern)
                {
                    if (text.Substring(i, m).Equals(pattern) && logging)
                        Console.WriteLine("Pattern found in " + (i + m));
                }
            }
        }

        #endregion
        #region utilities

        static ulong ComputeHash(string text)
        {
            const ulong p = 100007;
            ulong hash = 0;
            ulong D = 256;
            for (int i = 0; i < text.Length; i++)
            {
                hash = (hash * D + (ulong)text[i]) % p;
            }
            return hash;
        }

        static int[] GenerateKMPTable(string pattern)
        {
            int[] T = new int[pattern.Length];
            int i = 1;
            int j = 0;

            while (i < pattern.Length)
            {
                if (pattern[i] == pattern[j])
                {
                    j++;
                    T[i] = j;
                    i++;
                }
                else
                {
                    if (j > 0)
                        j = T[j - 1];
                    else
                    {
                        T[i] = j;
                        i++;
                    }
                }
            }

            return T;
        }
        #endregion
    }
}
